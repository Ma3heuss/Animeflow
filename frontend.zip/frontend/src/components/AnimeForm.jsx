import { useState } from 'react'

//const guarda a informacao digitada pelo usuario como nome,genero

export default function AnimeForm({ onAdd }) {
  const [nome, setNome] = useState('')
  const [genero, setGenero] = useState('')
  const [ano, setAno] = useState('')
  const [finalizado, setFinalizado] = useState(false)
  const [erro, setErro] = useState('')

//nao deixa o formulario recarregar a pagina 

  function handleSubmit(e) {
    e.preventDefault()

//verifica se nome genero e ano estao vazios se nao mostra uma mensagem na tela

    if (!nome.trim() || !genero.trim() || !ano) {
      setErro('Preencha nome, gênero e ano antes de cadastrar.')
      return
    }

//remove os espacos antes e depois de cada um muda o ano para number e avisa se o anime foi finalizado

    onAdd({
      nome: nome.trim(),
      genero: genero.trim(),
      ano: Number(ano),
      finalizado,
    })

//limpa os campos para que venha o proximo cadastro

    setNome('')
    setGenero('')
    setAno('')
    setFinalizado(false)
    setErro('')
  }

//html que sera retornado

  return (
    <form className="anime-form" onSubmit={handleSubmit}>
      <h2>Adicionar anime</h2>

      {erro && <p className="form-erro">{erro}</p>}

      <div className="form-linha">
        <input
          type="text"
          placeholder="Nome do anime"
          value={nome}
          onChange={(e) => setNome(e.target.value)}
        />
        <input
          type="text"
          placeholder="Gênero (ex: Shounen)"
          value={genero}
          onChange={(e) => setGenero(e.target.value)}
        />
        <input
          type="number"
          placeholder="Ano"
          value={ano}
          onChange={(e) => setAno(e.target.value)}
        />
      </div>

      <label className="form-checkbox">
        <input
          type="checkbox"
          checked={finalizado}
          onChange={(e) => setFinalizado(e.target.checked)}
        />
        Já finalizei de assistir
      </label>

      <button type="submit">Adicionar</button>
    </form>
  )
}
