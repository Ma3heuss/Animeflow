//importa o css e os componentes alem do usestate e useeffect
import { useState, useEffect } from 'react'
import SearchBar from './components/SearchBar.jsx'
import AnimeForm from './components/AnimeForm.jsx'
import AnimeList from './components/AnimeList.jsx'
import './App.css'

//url que do django que o react vai usar
const API_URL = 'http://127.0.0.1:8000/api/animes/'

export default function App() {
  const [animes, setAnimes] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')
  const [sortBy, setSortBy] = useState('nome')
  const [mostrarForm, setMostrarForm] = useState(false)
  const [finalizado, setFinalizado] = useState('')

  //assim que pesquisar ele aguarda o tempo para fazer a requisicao
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      buscarAnimes(search, finalizado)
    }, 300)

    //caso a pessoa ainda esteja digiando 

    return () => clearTimeout(timeoutId)
  }, [search, finalizado])
  //funcao que busca os animes no django 
  //informa que os dados estao sendo carregados
  async function buscarAnimes(nome, finalizado) {
  setLoading(true)
  setError('')

  try {
    const params = new URLSearchParams()

    if (nome) {
      params.append('nome', nome)
    }

    if (finalizado !== '') {
      params.append('finalizado', finalizado)
    }

    const url = params.toString()
      ? `${API_URL}?${params.toString()}`
      : API_URL

    const resposta = await fetch(url)

    if (!resposta.ok) {
      throw new Error('Falha ao buscar')
    }

    const dados = await resposta.json()
    setAnimes(dados)

  } catch (err) {
    setError(
      'Não foi possível carregar os animes. Verifique se a API Django está rodando.'
    )
  } finally {
    setLoading(false)
  }
}

  //funcao que cria um novo anime
  async function handleAdd(novoAnime) {
    try {
      const resposta = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(novoAnime),
      })
      if (!resposta.ok) throw new Error('Falha ao cadastrar')
      const criado = await resposta.json()
      setAnimes((atual) => [criado, ...atual])
      setMostrarForm(false)
    } catch (err) {
      setError('Não foi possível cadastrar o anime.')
    }
  }
  //funcao responsavel por excluir um anime pelo ID
  async function handleDelete(id) {
    try {
      const resposta = await fetch(`${API_URL}${id}/`, { method: 'DELETE' })
      if (!resposta.ok) throw new Error('Falha ao excluir')
    
      setAnimes((atual) => atual.filter((anime) => anime.id !== id))
    } catch (err) {
      setError('Não foi possível excluir o anime.')
    }
  }
  //cria uma lista com os arquivos ordenados por ano ou nome
  const animesOrdenados = [...animes].sort((a, b) => {
    if (sortBy === 'ano') return a.ano - b.ano
    return a.nome.localeCompare(b.nome)
  })
//html do app
  return (
    <div className="app">
      <header className="app-header">
        <h1>AnimeFlow</h1>
        <p>sua lista pessoal de animes</p>
      </header>

      <div className="app-controles">
        <div className="filtro-finalizado">
          <div className="filtro-finalizado">
  <button
    className={finalizado === '' ? 'ativo' : ''}
    onClick={() => setFinalizado('')}
  >
    Todos
  </button>

  <button
    className={finalizado === 'false' ? 'ativo' : ''}
    onClick={() => setFinalizado('false')}
  >
    Assistindo
  </button>

  <button
    className={finalizado === 'true' ? 'ativo' : ''}
    onClick={() => setFinalizado('true')}
  >
    Finalizados
  </button>
</div>

</div>
        <SearchBar value={search} onChange={setSearch} />
        <button className="btn-toggle" onClick={() => setMostrarForm((v) => !v)}>
          {mostrarForm ? 'Cancelar' : '+ Novo anime'}
        </button>
      </div>

      {mostrarForm && <AnimeForm onAdd={handleAdd} />}

      <AnimeList
        animes={animesOrdenados}
        loading={loading}
        error={error}
        onDelete={handleDelete}
        sortBy={sortBy}
        onSortChange={setSortBy}
      />
    </div>
  )
}
