from django.db import models

#cria a tabela com as seguintes opcoes (nome,genero,ano,finalizado)
#ordering define a ordem q os animes vao ser apresentados nesse caso 
#os animes novos em cima e os antigos em baixo
#return self.nome e para retornar nome dos animes 
class Anime(models.Model):
    nome = models.CharField(max_length=150)
    genero = models.CharField(max_length=50)
    ano = models.IntegerField()
    finalizado = models.BooleanField(default=False)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.nome
