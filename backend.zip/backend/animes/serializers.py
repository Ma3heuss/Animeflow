from rest_framework import serializers
from .models import Anime

#serializer vai transformar o arquivo do models em json para a api entender
class AnimeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Anime
        fields = ['id', 'nome', 'genero', 'ano', 'finalizado']
