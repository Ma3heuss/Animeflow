from rest_framework.routers import DefaultRouter
from .views import AnimeViewSet

#router cria varias rotas para poder acessar sem ter q escrever cada url separadamente

router = DefaultRouter()
router.register(r'animes', AnimeViewSet, basename='anime')

urlpatterns = router.urls
