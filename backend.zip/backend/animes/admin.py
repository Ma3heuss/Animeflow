from django.contrib import admin
from .models import Anime

#registra a tabela Anime no banco de dados \admin do django

admin.site.register(Anime)
