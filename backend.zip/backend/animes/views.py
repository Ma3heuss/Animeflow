from rest_framework import viewsets
from .models import Anime
from .serializers import AnimeSerializer

#fornece as funceos que vamos usar como GET,POST,DELETE
#define o serializador que vai ser usado
class AnimeViewSet(viewsets.ModelViewSet):
    serializer_class = AnimeSerializer

#funcao que permite a gente filtrar os nomes 
    def get_queryset(self):
        queryset = Anime.objects.all()
        nome = self.request.query_params.get('nome')
        finalizado = self.request.query_params.get('finalizado')
        if nome:
            queryset = queryset.filter(nome__icontains=nome)
        if finalizado == "true":
            queryset = queryset.filter(finalizado= True)
        elif finalizado == "false":
            queryset = queryset.filter(finalizado= False)
        return queryset
    
