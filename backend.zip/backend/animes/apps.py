from django.apps import AppConfig

#e basicamente os parametros sendo dados ao django como 
#define como django vai criar os id 
#e fala que o nome da aplicacao e animes
class AnimesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'animes'
