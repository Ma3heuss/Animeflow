from django.contrib import admin
from django.urls import path, include

#cria as urls para poder acessar o admin do django e a api

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('animes.urls')),
]
